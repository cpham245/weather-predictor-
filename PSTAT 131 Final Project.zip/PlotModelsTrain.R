## Plotting Our Models 📍

# After loading in our saved models, we can begin plotting them. We can also then investigate their ROC AUC and accuracy performances (for baseline model) as well.

### Multinomial Logistic Regression ROC plot 📝

# We can start by visualizing the performance of our Multinomial Logistic Regression model.

# Logistic Regression
lg_predictions <- augment(weather_lgfit, new_data = weather_train, type = "prob")
lg_trainroc <- lg_predictions %>%
  roc_curve(weather_type, .pred_Rainy:.pred_Snowy) %>%
  autoplot()
lg_trainroc


# For our ROC curves, the closer the curve is to the top left corner (reaching 1.00), the better the model classifies weather types. For `Snowy` and `Sunny`, the curves look great, almost hugging the top-left corner which means the model is doing a solid job at predicting these types. `Cloudy` and `Rainy` also perform well, but their curves are not as close.

# Our ROC curves seem to perform well, but now let's see how the ROC AUC score and accuracy perform.

# Best Multinomial Logistic Regression 
weather_lgfit <- fit_resamples(weather_lgworkflow, 
                               resamples = weather_folds,
                               metrics = metric_set(roc_auc, accuracy))
collect_metrics(weather_lgfit)



# With our multinomial logistic regression model achieving an accuracy of 86.2% and a ROC AUC of 95.7%, it indicates our model is effective at classifying weather types! This model sets a excellent baseline, providing a reliable benchmark as we explore more of our advanced models in the next section.

### Decision Tree Autoplot 📉

# Unlike Logistic Regression, which relies on linear relationships between predictors, a Decision Tree splits the data into hierarchical branches based on feature importance. This makes it useful for capturing non-linear relationships and interactions between variables like `temperature`, `windspeed`, and `atmospres`. Let's now plot our decision tree.


# Decision Tree
autoplot(tune_dt, metric = "roc_auc")


# From our plot, we see that our decision tree model performs best at a cost complexity of 0.001 as our `roc_auc` is 0.98. We see that the ROC AUC decreases as the cost-complexity parameter increases, indicating our model's performance is better with a smaller complexity penalty.

### Pruned Decision Tree

# Decision Tree (pruned)
best_pruned <- select_best(tune_dt, metric = "roc_auc")
pruned_train <- finalize_workflow(dt_wf, best_pruned)
best_dt_train <- fit(pruned_train, weather_train)

best_dt_train %>%
  extract_fit_engine() %>%
  rpart.plot()

# Best Pruned Decision Tree
tune_dt %>%
  collect_metrics() %>% 
  arrange(desc(mean)) %>%
  slice(1:5)


# Seems like our pruned decision tree performs best with a cost complexity parameter of 0.001. With an impressive `roc_auc`score of 0.98, this model does a fantastic job at effectively distinguishing between different weather types.

### Random Forest Autoplot 〰️

# Random Forest
autoplot(tune_rf, metric = "roc_auc") +
  theme(plot.title = element_text(size = 10, face = "bold", hjust = 0.5))


# The ROC AUC scores vary depending on the number of trees but it seems that our performance stabilizes as the number of trees increase so adding more trees would no longer significantly improve our performance. However, our `mtry` values between 5-6 result in slightly better performances as seen above, meaning minimal node sizes with smaller values achieve higher `roc_auc` for our model.

# From our Random forest plot, we claimed that our model performs best with a `mtry` of 5-6, so let's take a look and see a few of our best-performing RFs.

tune_rf %>%
  collect_metrics() %>%
  arrange(desc(mean)) %>%
  slice(1:5)


# The table suggests a `mtry` between 5-6 is a solid spot for achieving the greatest `roc_auc`, with our best performing Random forest #385 achieving a ROC AUC of 0.993 with `mtry = 5`, `trees = 555`, and `min_n = 15`.

### Boosted Tree Autoplot 📏

# Boosted Tree Model
autoplot(tune_bt, metric = "roc_auc")


# Here, across all panels, the ROC AUC scores seem to be stable and close to 1, which suggests that our model is not sensitive to learning rate and performs well!
  

# Boosted Tree Performance
tune_bt %>%
  collect_metrics() %>%
  arrange(desc(mean)) %>%
  slice(1:5)


# Our XG-Boosted tree model performs with ROC AUC values consistently around 0.994, displaying an excellent score. Interestingly, the model isn't highly sensitive to changes in parameters like `mtry`, `trees`, or `learn_rate`. Here, our standout model is XG-Boosted tree model #83, with a `mtry = 5`, `trees = 755`, and `learn_rate = 1e-02`.

### SVM Model Autoplot 📈

#SVM Model
autoplot(tune_svm, metric = "roc_auc")


# From this autoplot, we observe that performance increases from 0.0078 to 2, eventually achieving its peak ROC AUC of approximately 0.96. However, beyond a cost of 2, the performance starts to decline slightly. Therefore, a moderate cost around 2 is the best balance between underfitting and overfitting for this dataset.

tune_svm %>%
  collect_metrics() %>%
  arrange(desc(mean)) %>%
  slice(1:5)



# Our SVM model's ROC AUC varies more than the other models, with the best SVM model being SVM model #4, with a score of 0.968 and cost of 2.378.