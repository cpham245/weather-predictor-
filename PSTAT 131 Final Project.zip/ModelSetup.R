## Setting Up Our Models ⏫

#With our data exploration complete and key variables identified, we’re ready to start building the predictive models. We'll begin by splitting our data into training and testing sets to evaluate model performance effectively. Next we'll set up a preprocessing recipe to standardize and prepare the features for modeling. Finally, we'll implement cross-validation to ensure our models are robust and generalize well across different subsets of the dataset. Let's dive in and start training!
  
### Data Split
  
# As we move into model building, our first task is to split the dataset into two parts: a training set (70%) for developing the models, and a testing (30%) that will be used later to evaluate their performance. We’ll start by setting a random seed to ensure that the split is reproducible every time we run the process. Then, we’ll perform a stratified split to maintain the balance of our target variable `weather_type` across both sets, ensuring fair and consistent evaluation during testing.

#Set seed
set.seed(1178)

#Split into training and testing set
weather_split <- weather%>%
  initial_split(prop = 0.70, strata = weather_type)

weather_train <- training(weather_split) 
weather_test <- testing(weather_split) 


# Let's first take a look at the dimensions of our training and testing set. For our training set, we see that we have 9240 observations which is about 70% of our weather dataset.


#Dimensions of testing set
dim(weather_train) #9240


# And for our testing set, we have 3960 observations which is about 30% of our weather dataset.

# Dimensions of training set
dim(weather_test) #3960


### Creating our Recipe 🥣

# To ensure consistency across all models, we’ll create a recipe for preprocessing our data, adjusting it only when necessary for specific models. This recipe will standardize the predictors and prepare the categorical variables for analysis.

# The predictors selected for our recipe include `temp`, `humidity`, `windspeed`, `precip`, `cloudcover`, `atmospres`, `uvindex`, `season`, `visibility`, and `location`. These variables were chosen based on their relevance to predicting weather types as observed in our exploratory analysis.

# In this recipe, we will:

# -   Encode Categorical Variables: Transform categorical predictors like cloudcover and season into dummy variables to make them usable in the models.

# -   Normalize Predictors: Center and scale all numeric predictors to prevent variables with larger ranges from dominating the model.

# -   Preprocessing: Use the same recipe for all models to maintain consistency, reducing the chance of discrepancies in variable handling.

### Checking our columns within our categorical variables

weather_recipe <- recipe(weather_type ~ temp + humidity + windspeed +   
                         precip + cloudcover + atmospres + uvindex +    
                         season + visibility + location, data = weather_train) %>% 
  step_dummy(cloudcover, season, location, one_hot = TRUE) %>%  # one-hot-encoding
  prep()

# Bake the recipe and inspect the dummy variables
weather_bake <- bake(weather_recipe, new_data = NULL)

#Summarize totals for dummy variables
weathercloud_total <- weather_bake %>%
  select(starts_with("cloudcover"), starts_with("season"), starts_with("location")) %>%
  summarise(across(everything(), sum))

weathercloud_total

# Taking a look, we see that `cloudcover = cloudy` only has 279 observations whereas `cloudcover = overcast` has 4256 observations, `cloudcover = clear` has 1481 observations, and `cloudcover = party cloudy` has 3224 observations. Since there are so few cloudy observations, we can choose to remove or merge it from our dataset. In our case, we will be merging cloudy observations with overcast observations.

### Merging Cloudy with Overcast Observations

# For training set
weather_train <- weather_train %>%
  mutate(cloudcover = as.character(cloudcover)) %>% # ensure it's a character column
mutate(cloudcover = recode(cloudcover, "cloudy" = "overcast")) %>% # recode values
  mutate(cloudcover = as.factor(cloudcover)) # convert back to factor

# For testing set
weather_test <- weather_test %>%
  mutate(cloudcover = as.character(cloudcover)) %>% # ensure it's a character column
  mutate(cloudcover = recode(cloudcover, "cloudy" = "overcast")) %>% # recode values
  mutate(cloudcover = as.factor(cloudcover)) # convert back to factor

# Check Merge observations
weather_bake %>%
  select(starts_with("cloudcover")) %>%
  summarise(across(everything(), sum))


### Our Final Recipe 🧑‍🍳

#Let's now finalize our recipe.

weather_recipe <- recipe(weather_type ~ temp + humidity + windspeed +   
                         precip + cloudcover + atmospres + uvindex +    
                         season + visibility + location, data = weather_train) %>% 
  step_dummy(cloudcover, season, location, one_hot = TRUE) %>%  # one-hot-encoding
  step_normalize(all_predictors())


### K-Crossfold Validation

# Before moving on, we need to fold the training set using *v*-fold cross-validation, with `v = 10` to stratify on our outcome variable `weather_type`.

weather_folds <- vfold_cv(weather_train, v = 10, strata = weather_type)

