## Exploratory Data Analysis 🔎

#In this section, we'll dive into the dataset to uncover initial insights and understand the structure of the data. Our goal is to set the foundation for feature engineering and modeling by exploring key patterns and relationships in the data.

### Loading Packages and Our Data 📦

#Let's first load in our weather data.

library(tidyverse)
library(dplyr)
library(tidymodels)
library(corrplot)
library(ggplot2)
library(discrim)
library(DT)
library(ISLR2)
library(kernlab)
library(yardstick)
library(rpart)
library(rpart.plot)
library(vip)

# Loading Dataset
#weather <- read_csv("~/PSTAT 131/weather_classification_data.csv") 
#tidymodels_prefer()
#set.seed(1178)

#Make interactive datatable
datatable(weather, options = list(scrollX = TRUE, pageLength = 6))

#This weather data was obtained from the Kaggle dataset, ["Weather Type Classification"](https://www.kaggle.com/datasets/nikhil7280/weather-type-classification). The dataset was created by Nikhil Narayan.

### Data Observations 👀

#Since we loaded in our dataset, let's see how many observations and features we have.

# dim() to see how many rows and columns are in our dataset
dim(weather)

#From above, we see that the data set contains 13,200 total rows and 11 total predictors! Our data set doesn't have too many predictors to narrow down, but we will still check to see which predictors are not necessary.

#Let's take a look at the list of potential predictors.

# Checking the names of our predictors
colnames(weather)


### Removing Predictors? ❌

#All of variables seem to be relevant to our dataset, we will not be dropping any of them for now.

### Categorical Variables 🐱

#Our categorical variables are `Cloud Cover`, `Season`, `Location`, and `Weather Type`.

# Checking categorical variables
cat_weather <- weather %>%
  select(where(is.character), where(is.factor)) %>%
  names()

cat_weather

### Numeric Variables 🔢

#Our numeric variables are `Temperature`, `Humidity`, `Wind Speed`, `Precipitation (%)`, `Atmospheric Pressure`, `UV Index`, and `Visibility (km)`.

# Checking numeric variables
num_weather <- weather %>%
  select(where(is.numeric)) %>%
  names()

num_weather

### Data Cleaning 🧹

#Let's first rename our columns for easier accessibility and readability.

#Renaming columns
# weather <- weather %>%
#  rename(
#    temp = Temperature,
#    humidity = Humidity,
#    windspeed = `Wind Speed`,
#    precip = `Precipitation (%)`,
#    cloudcover = `Cloud Cover`,
#    atmospres = `Atmospheric Pressure`,
#    uvindex = `UV Index`,
#    season = Season,
#    visibility = `Visibility (km)`,
#    location = Location,
#    weather_type = `Weather Type`)

#Check Our Renamed Predictors
colnames(weather)


#Perfect! Our new column names will make it easier to search them up.

### Factoring Categorical Variables 🫴

#By converting our categorical variables into factors, they will be easier to handle during modeling.

weather <- weather %>%
  mutate(weather_type = factor(weather_type, 
                               levels = c("Rainy", "Sunny", "Cloudy", "Snowy")),
         cloudcover = as.factor(cloudcover),
         season = as.factor(season),
         location = as.factor(location))



### Missing Values? ☹️

#Before modeling, we need to check if we have any missing values in our dataset.

# Checking if there are any missing values in our data set
sum(is.na(weather))


#Lucky! Lucky! We see that there is no missing values in our dataset so there will be no need for imputation.