## Best Model(s) Performance 💯

#Now let's take a look at how well our models (Random forest & XG-Boosted Tree) perform on the testing set.

#```{r pressure, echo=FALSE, out.width = '40%', out.height = '40%'}
#knitr::include_graphics("xgboost.png")
#```

### Best Random Forest Model Peformance 🌲

#Let's see if it can beat our XG-Boosted Tree model.

# Test Random Forest #385
best_rf_model <- select_best(tune_rf)
rf_finalwf <- finalize_workflow(rf_wf, best_rf_model)
final_rf_model <- fit(rf_finalwf, weather_train)

final_rf_test <- augment(final_rf_model, weather_test) %>%
  select(weather_type, starts_with(".pred"))

roc_auc(final_rf_test, truth = weather_type, .pred_Rainy:.pred_Snowy) %>% mutate(.estimate = round(.estimate, 5))


# ROC Curve
roc_curve(final_rf_test, truth = weather_type, .pred_Rainy:.pred_Snowy) %>%
  autoplot()


# Wow! Our Random Forest model #385 absolutely crushes it on our testing dataset. The ROC curves for all four weather types `Cloudy`, `Rainy`, `Snowy`, and `Sunny` are practically hugging the top-left corner, showing near-perfect sensitivity and specificity. We also see it has a `roc_auc` score of 0.9941. This might just be our best model!

## Best Boosted Tree Model Performance 🌳🌳🌳

# The Random Forest Model had a high performance, can our XG-Boosted Tree Model beat it?
  
# Test Boosted Tree Model
best_bt_model <- select_best(tune_bt)
bt_finalwf <- finalize_workflow(bt_wf, best_bt_model)
final_bt_model <- fit(bt_finalwf, weather_train)

final_bt_test <- augment(final_bt_model, weather_test) %>%
  select(weather_type, starts_with(".pred"))

roc_auc(final_bt_test, truth = weather_type,
        .pred_Rainy:.pred_Snowy) %>%
  mutate(.estimate = round(.estimate, 5))


# ROC Curve
roc_curve(final_bt_test, truth = weather_type, .pred_Rainy:.pred_Snowy) %>%
  autoplot()


# Take a look at this! Our XG-Boosted Tree model performs about the same, but falls short about by 0.00007. So Close! However, it performs remarkably with a `roc_auc` of 0.99408 and as seen in the autoplot, almost makes a perfect upside down L.
