## Model Comparison Results 🕵

# Since we've ran all our models on our training set, let's compile their results into a table for easier readability.

lg_train <- collect_metrics(weather_lgfit) %>%
  filter(.metric %in% "roc_auc") %>%
  select(.metric, mean) %>%
  arrange(desc(mean)) %>%
  slice(1) %>%
  mutate(Model = "Multinomial Logistic Regression")

dt_train <- collect_metrics(tune_dt) %>%
  filter(.metric %in% "roc_auc") %>%
  select(.metric, mean) %>%
  arrange(desc(mean)) %>%
  slice(1) %>%
  mutate(Model = "Pruned Decision Tree")

rf_train <- collect_metrics(tune_rf) %>%
  filter(.metric %in% "roc_auc") %>%
  select(.metric, mean) %>%
  arrange(desc(mean)) %>%
  slice(1) %>%
  mutate(Model = "Random Forest")

bt_train <- collect_metrics(tune_bt) %>%
  filter(.metric %in% "roc_auc") %>%
  select(.metric, mean) %>%
  arrange(desc(mean)) %>%
  slice(1) %>%
  mutate(Model = "XGBoost Model")

svm_train <- collect_metrics(tune_svm) %>%
  filter(.metric %in% "roc_auc") %>%
  select(.metric, mean) %>%
  arrange(desc(mean)) %>%
  slice(1) %>%
  mutate(Model = "Support Vector Machine ")

weather_train_results <- bind_rows(lg_train, dt_train, rf_train, bt_train, svm_train) %>%
  arrange

weather_train_results

#| Model                           | ROC AUC Values |
#  |---------------------------------|----------------|
#  | Multinomial Logistic Regression | 0.95719        |
#  | Pruned Decision Tree            | 0.98170        |
#  | Random forest                   | 0.99362        |
#  | XG-Boosted Tree                 | 0.99366        |
#  | Support Vector Machine          | 0.96860        |
  
# We see that our Random forest and XG-Boosted tree perform neck-to-neck, with ROC AUC values of 0.993. Since they both had similar performances, we're going to select these two as our final models to see how they perform on our testing set.
