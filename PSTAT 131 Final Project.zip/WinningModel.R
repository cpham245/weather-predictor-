## Our Winning Model 🌟

#So...... the best model goes to... Random Forest #385 with a ROC AUC score of 0.99!

#```{r, echo=FALSE, out.width = '40%', out.height = '40%'}
#knitr::include_graphics("giphy.webp", error = FALSE)
#```

### Good Accuracy? ✅

#Since we already have seen our best model's ROC AUC, let's also see its accuracy.

#accuracy(final_rf_test, truth = weather_type, .pred_class)


#Our Random Forest model achieved a strong 91.9% accuracy on the test data, meaning it was able to predict different weather types with that high of an accuracy!
  
  
### Variable Importance Chart ⛅
  
# Since our Random Forest Model was our winner, let's take a deep dive and see what were the most important features.

final_rf_model %>%
  extract_fit_parsnip() %>%
  vip::vi() %>%
  mutate(
    Variable = case_when(
      startsWith(Variable, "cloudcover") ~ "cloudcover",
      startsWith(Variable, "season") ~ "season",
      startsWith(Variable, "location") ~ "location",
      TRUE ~ Variable
    )
  ) %>%
  group_by(Variable) %>% # Group by combined variables
  summarize(Importance = sum(Importance), .groups = "drop") %>% # Sum importance for each group
  ggplot(aes(x = reorder(Variable, Importance), y = Importance, fill = Variable)) +
  geom_bar(stat = "identity", color = "black") +
  scale_fill_brewer(palette = "Set3") +
  coord_flip() +
  xlab("Variables")


#In our Random Forest model, `temp` stands out as the most influential factor in predicting weather types, which aligns with its fundamental role in weather patterns.

#`visibility`, `uvindex`, and `precip` follow closely, indicating their importance in distinguishing between different weather conditions, such as clear skies or rain. `atmospres` also plays a significant role, helping the model identify shifts in weather systems.

#`season` and `cloudcover` provide additional context, while features like humidity, wind speed, and location have less influence but still contribute valuable details to refine predictions. This combination of factors gives our model a strong foundation for accurate weather classification.