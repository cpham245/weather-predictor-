## Visual EDA ✨

#Our data is now ready to go, so let’s dive into some visual exploratory data analysis! Before we get into the exciting part of building our predictive models, it’s important to understand the relationships between our predictors and the target variable, `weather_type`. We’ll start by examining the distribution of our response variable and identifying potential correlations between predictors. Additionally, we’ll create some visualizations using `ggplot2` to explore how specific features like `Temperature`, `Humidity`, and `Cloud Cover` affect the weather type.

### Variable Correlation Plot 🖇️

#To identify potential multicollinearity and understand the relationships between our numeric predictors, we’ll create a correlation matrix. This matrix will help us see which features are strongly correlated, and could inform our feature selection process later on.

weather %>%
  select(where(is.numeric)) %>%
  cor() %>%
  corrplot(type = 'lower', diag = FALSE, method = 'color', addCoef.col = 'black', number.cex = 0.6, tl.cex = 0.6) 


# From the correlation plot above, we can draw several interesting insights about the relationships between our numerical predictors. We see that `humidity` and `precip` are highly correlated, which makes sense since humid air typically holds more moisture, leading to higher chances of rain. We also see that there is a moderate positive correlation between `temp` and `uvindex` which also makes sense since higher temperatures often occur on sunny days with more ultraviolet radiation. The stronger the sunlight, the higher the UV index, typically leading to warmer conditions. Additionally, there is a negative correlation between `visibility` and both `humidity` and `precip`. This alighns with our expected results since fog, rain, or other forms of precipitation often reduce visibility. High humidity also contributes to haze or fog, reducing visibility further. Surprisingly, `atmospres` does not show a strong correlation with other variables. I had expected pressure to play a significant part in weather changes, such as influencing wind speeds or precipitation patterns.

### Distributions 📊

#Now that we have explored the relationships between our predictors using a correlation plot, let's take a closer look at the individual distributions of some key variables. We’ll create visualizations to understand how these features vary across different weather types and identify any patterns that may inform our model building.

### Weather Type 🌧️🌞☁️❄️

#First, let's take a look at the distribution of our outcome, `weather_type`.

weather %>%
  ggplot(aes(x = weather_type, fill = weather_type)) +
  geom_bar(color = "black") +
  scale_fill_brewer(palette = "Set3") +
  xlab("Weather Type") +
  ylab("Count")+
  ggtitle("Distribution of Weather Types")+
  theme_minimal() +
  theme(plot.title = element_text(hjust=0.6)) 


#It seems that there is an even distribution of weather types in the dataset, each having around 3300 observations, so there is no unbalanced data.

### Temperature 🌡️

#Temperature is a key factor in shaping weather patterns. Colder temperatures align with snowy conditions, while warmer temperatures are typical for sunny weather. To better understand how temperature varies across different weather types, we will create a bar plot. This visualization will help us see the general temperature trends for each weather category.

# Create a bar plot to show the distribution of temperature (°C) across weather types
#weather %>%
  ggplot(aes(x = temp, fill = weather_type)) +
  geom_histogram(bins = 30, color = 'black') +
  scale_fill_brewer(palette = "Set3") +
  xlab("Temperature (°C) ") +
  ylab("Proportion") +
  ggtitle("Temperature Distribution across Weather Types") +
  theme_minimal() +  
  theme(plot.title = element_text(hjust=0.6))


# As we can see in the plot below, snowy conditions are most common at the lowest temperatures, while sunny weather peaks at much warmer ranges. In moderate temperature ranges (0°C to 40°C), we see a mix of cloudy and rainy days, reflecting the versatility of these weather types across different seasons. For context, temperatures above 30°C (86°F) would be considered quite hot, signaling summer-like conditions, while temperatures below 0°C (32°F) are typical for winter days with potential frost or snow.

### Humidity 💦

# Humidity is a crucial factor influencing weather conditions, as it represents the amount of moisture in the air. High humidity often accompanies rainy and overcast days, where moisture levels in the atmosphere are elevated. In contrast, lower humidity is typically observed during clear, sunny conditions.

weather %>%
  ggplot(aes(x = humidity, fill = weather_type)) +
  geom_histogram(bins = 30, color = 'black', alpha = 0.7) + 
  scale_fill_brewer(palette = "Set3") +
  xlab("Humidity") +
  ylab("Count") +
  ggtitle("Humidity Distribution Across Weather Types") +
  theme_minimal() + 
  theme(plot.title = element_text(hjust=0.5)) 

# From our histogram, we notice that Cloudy and Rainy weather types dominate the mid-to-high humidity range (50% to 80%), indicating moisture-rich conditions. Snowy weather also peaks in this range but is slightly more dispersed in the higher, while Sunny weather displays a broader distribution with fewer instances at high humidity levels.

### Windspeed 🍃

# Windspeed reflects the intensity of atmospheric activity. Strong winds are usually associated with stormy or unsettled weather, while lighter winds typically occur during calm, clear conditions.

weather %>%
  ggplot(aes(x = weather_type, y = windspeed, fill = weather_type)) +
  geom_boxplot(color = "black") +
  scale_fill_brewer(palette = "Set3") +
  xlab("Weather Type") +
  ylab("Wind Speed (km/hr)") +
  ggtitle("Windspeed Distribution Across Weather Types") +
  theme_minimal() + 
  theme(plot.title = element_text(hjust=0.5)) +
  coord_flip()


# As we can see above, Snowy and Rainy weather types exhibit the highest wind speeds, with many outliers indicating gusty conditions typical of storms. On the other hand, Sunny and Cloudy weather types generally have lower wind speeds, indicative of more stable and tranquil conditions.

### Atmospheric Pressure 💨

# Atmospheric pressure plays a key role in shaping weather types. High pressure is linked to stable, clear skies and sunny weather, while low pressure promotes rising air, leading to cloud formation and precipitation, common in Rainy and Snowy conditions. Cloudy weather often falls in between, with moderate pressure levels that support some cloud cover but not enough for heavy rain or snow.

weather %>%
  ggplot(aes(x = atmospres, fill = weather_type)) +
  geom_histogram(bins = 40, color = "black") +
  scale_fill_brewer(palette = "Set3") +
  xlab("Weather Type") +
  ylab("Atmospheric Pressure (hPa)") +
  ggtitle("Atmospheric Pressure Distribution Across Weather Types") +
  theme_minimal() +
  theme(plot.title = element_text(hjust=0.5)) 



# From our results, most of the pressure readings are concentrated between 1000 and 1040 hPa across all waether types. Cloudy and Sunny weather types dominate the higher pressure range, while Snowy and Rainy weather types appear more frequently at slightly lower pressures, aligning with the atmospheric instability typically associated with storms. Therefore, lower pressures correlate with adverse weather, while higher pressures are linked to clearer, calmer conditions.

### Cloud Cover ☁️

# For our final visual, we're going to take a look at the distribution of cloud cover. In general, we expect Cloudy and Rainy weather types to have higher cloud cover, while Sunny weather should show lower cloud cover.

weather %>%
  ggplot(aes(x = cloudcover, fill = weather_type)) +
  geom_bar(bins = 30, color = "black") +
  scale_fill_brewer(palette = "Set3") +
  xlab("Cloud Cover") +
  ylab("Proportion") +
  ggtitle("Cloud Cover Distribution Across Weather Types") +
  theme_minimal() +
  theme(plot.title = element_text(hjust=0.5)) 


As expected, Overcast conditions are dominated by Cloudy, Rainy, and Snowy weather types, indicating high cloud coverage typically associated with these conditions. Meanwhile, sunny weather is primarily seen in the Clear cloud cover category, reflecting minimal cloud conditions. I found it interesting that the Party Cloudy category shows a balanced mixture of all the weather types, but it makes sense since this cloud cover state often serves as a transitional phase for preceding rain, or sigfnaling a shift towards clearer skies. The Clear category is entirely made up of sunny weather, reinforcing the idea between minimal cloud cover and fair weather.