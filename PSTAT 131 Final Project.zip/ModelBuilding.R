## Building our Model 🛠

#With our weather dataset fully prepared, we can now proceed to model building. Since the dataset contains a mix of numerical and categorical features with moderate size, it provides an excellent opportunity to experiment with a range of classification models. Models like Logistic Regression, Linear Discriminant Analysis (LDA), and Quadratic Discriminant Analysis (QDA) will help establish baseline performance, while more advanced techniques, such as Random Forest, Gradient Boosted Trees, and Support Vector Machines (SVM), are well-suited for capturing complex patterns in the data.

#Each model will be assessed based on its ability to classify weather types accurately. To measure their performance, we’ll use key metrics such as accuracy and roc_auc, ensuring a thorough evaluation of each model’s strengths. Given the dataset's features, such as temperature, humidity, cloud cover, and wind speed, the advanced models are expected to leverage their strength in handling intricate relationships between predictors. Results will be saved and revisited for comparison, allowing us to determine which approach performs best for predicting weather conditions.

### The Process 📋

#**1. Model Setup**: We begin by specifying the type of model, setting its engine, and defining its mode. Since we are predicting weather types, the mode is set to classification.

#**2. Workflow Creation**: We establish a workflow by linking the selected model to the preprocessing recipe we created earlier. This ensures that each model uses the same standardized and encoded dataset for training.

#**3. Baseline Model**: We will be using Logistic regression as our baseline model. It is straightforward and does not require hyperparameter tuning. It is fit directly to the training data using the established workflow to provide a benchmark for evaluating other models.

#**4. Tuning Advanced Models**: For more complex models like Decision Tree, Random Forest, Gradient Boosted Trees, and Support Vector Machines (SVM), we set up a tuning grid to explore a range of hyperparameter values. For instance, we may tune the number of trees or the learning rate in boosted trees or the kernel type in SVMs.

#**5. Selecting the Best Hyperparameters**: Using cross-validation, we determine the optimal hyperparameters for each advanced model by testing various combinations. The hyperparameters that yield the best performance are finalized in the workflow.

#**6. Model Fitting**: Once the workflows are finalized, we fit each model to the training dataset. This step ensures the models are optimized based on the training data.

#**7. Saving Results**: The trained models and their workflows are saved as .rda files. This allows us to revisit and compare results later without needing to re-train the models.

### Baseline Model Setup ✏️

#Following our process, we're going to try fitting our training data to our multinomial logistic regression model.

# Multinomial Logistic regression 
weather_lg <- multinom_reg() %>%
  set_engine("nnet") %>%
  set_mode("classification")

weather_lgworkflow <- workflow() %>%
  add_model(weather_lg) %>%
  add_recipe(weather_recipe)

weather_lgfit <- fit(weather_lgworkflow, data = weather_train)


### Advanced Models Setup ⚙️

#Since we have built our baseline model, let's now build our other models: Decision Tree, Random Forest, XG-Boosted Trees, and Support Vector Machines.

# Decision Tree (Pruned)
dt_model <- decision_tree() %>%
  set_engine("rpart") %>%
  set_mode("classification") %>%
  set_args(cost_complexity = tune())

# DT workflow
dt_wf <- workflow() %>%
  add_model(dt_model) %>%
  add_recipe(weather_recipe)

# DT Grid
dt_grid <- grid_regular(cost_complexity(range = c(-3, -1)), levels = 10)

# Random Forest
rf_model <- rand_forest(mtry = tune(),
                        trees = tune(),
                        min_n = tune()) %>%
  set_engine("ranger", importance = "impurity") %>%
  set_mode("classification")

# RF workflow
rf_wf <- workflow() %>%
  add_model(rf_model) %>%
  add_recipe(weather_recipe)

# RF Grid
rf_grid <- grid_regular(mtry(range = c(5, 10)),
                        trees(range = c(200, 1000)),
                        min_n(range = c(5, 20)),
                        levels = 10)

# Boosted Trees
bt_model <- boost_tree(mtry = tune(), 
                           trees = tune(), 
                           learn_rate = tune()) %>%
  set_engine("xgboost") %>% 
  set_mode("classification")

# BT workflow
bt_wf <- workflow() %>%
  add_model(bt_model) %>%
  add_recipe(weather_recipe)

#BT grid
bt_grid <- grid_regular(mtry(range = c(5, 10)),
                        trees(range = c(400, 2000)),
                        learn_rate(range = c(-10, -1)),
                        levels = 10)

# Support Vector Machines 
svm_model <- svm_rbf(cost = tune()) %>%
  set_mode("classification") %>%
  set_engine("kernlab")

# SVM workflow
svm_rbf_wkflow <- workflow() %>%
  add_recipe(weather_recipe) %>%
  add_model(svm_model)

# SVM Grid
svm_rbf_grid <- grid_regular(cost(), levels = 5)



### Tuning our Advanced Models 📈

#Now that we have set up our models, let's try tuning and running our models. This may take awhile.

# Tuning Pruned Decision Tree Model 
tune_dt <- tune_grid(
  dt_wf,
  resamples = weather_folds,
  grid = dt_grid,
  metrics = metric_set(roc_auc, accuracy))

save(tune_dt, file = "tune_dt.rda")

# Tuning Random Forest Model
tune_rf <- tune_grid(
  rf_wf,
  resamples = weather_folds,
  grid = rf_grid,
  metrics = metric_set(roc_auc, accuracy))

save(tune_rf, file = "tune_rf.rda")

# Tuning Boosted Tree Model 
tune_bt <- tune_grid(
  bt_wf,
  resamples = weather_folds,
  grid = bt_grid,
  metrics = metric_set(roc_auc, accuracy))

save(tune_bt, file = "tune_bt.rda")

# Tuning SVM Model
tune_svm <- tune_grid(
  svm_rbf_wkflow,
  resamples = weather_folds,
  grid = svm_rbf_grid,
  metrics = metric_set(roc_auc, accuracy))

save(tune_svm, file = "tune_svm.rda")


### Loading Models ⏳

# Phew, they finally saved in time. Now, let's load in our saved models.

load("tune_dt.rda")
load("tune_rf.rda")
load("tune_bt.rda")
load("tune_svm.rda")

