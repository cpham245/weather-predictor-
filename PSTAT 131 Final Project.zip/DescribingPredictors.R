## Describing the Predictors 🤓

#After cleaning the data, let’s take a closer look at the remaining features. Below is a detailed description of each predictor that we will use in our final model:
  
#  -   `temp` (numeric): The temperature in degrees *Celsius*, ranging from extreme cold to extreme heat.

# -   `humidity`(numeric): The humidity percentage, including values above 100% to introduce outliers.

# -   `windspeed`(numeric): The wind speed in kilometers per hour, with a range including unrealistically high values.

# -   `precip`(numeric): The precipitation percentage, including outlier values.

# -   `cloudcover`(categorical): The cloud cover description.

# -   `atmospres`(numeric): The atmospheric pressure in hPa, covering a wide range.

# -   `uvindex`(numeric): The UV index, indicating the strength of ultraviolet radiation.

# -   `season`(categorical): The season during which the data was recorded.

# -   `visibility`(numeric): The visibility in kilometers, including very low or very high values.

# -   `location`(categorical): The type of location where the data was recorded.

# -   `weather_type`(categorical): The target variable for classification, indicating the weather type.